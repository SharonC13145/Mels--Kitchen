export default function App() {
  return (
    <div style={{
      minHeight: '100vh',
      background: 'black',
      color: 'gold',
      fontFamily: 'Arial',
      padding: '40px'
    }}>
      <h1 style={{fontSize:'48px'}}>MELS KITCHEN</h1>
      <p>Authentic Flavours Nationwide</p>

      <section style={{
        marginTop:'40px',
        padding:'30px',
        border:'1px solid gold',
        borderRadius:'20px'
      }}>
        <h2>About Us</h2>
        <p>
          Mels Kitchen is a registered food and catering business in KwaZulu-Natal
          specialising in gourmet pies, frozen savouries, platters, catering and
          authentic homemade meals.
        </p>
      </section>

      <section style={{
        marginTop:'40px',
        padding:'30px',
        border:'1px solid gold',
        borderRadius:'20px'
      }}>
        <h2>Operating Hours</h2>
        <p>Monday – Saturday | 8:00 AM – 6:00 PM</p>
      </section>

      <section style={{
        marginTop:'40px',
        padding:'30px',
        border:'1px solid gold',
        borderRadius:'20px'
      }}>
        <h2>Ordering Policy</h2>
        <p>
          Orders must be placed at least 3 days in advance to secure delivery and preparation.
        </p>
      </section>

      <section style={{
        marginTop:'40px',
        padding:'30px',
        border:'1px solid gold',
        borderRadius:'20px'
      }}>
        <h2>Menu Highlights</h2>

        <ul>
          <li>Medium Gourmet Pies – R70 for 2</li>
          <li>Mini Mutton Curry Pies – R13 each</li>
          <li>Samoosas – R65 a dozen</li>
          <li>Spring Rolls – R70 a dozen</li>
          <li>Chicken Wings (20pc) – R180</li>
        </ul>
      </section>

      <section style={{
        marginTop:'40px',
        padding:'30px',
        border:'1px solid gold',
        borderRadius:'20px'
      }}>
        <h2>Contact</h2>
        <p>WhatsApp Orders: 073 078 7203</p>
        <p>Serving Durban, Johannesburg & Cape Town</p>
      </section>
    </div>
  )
}
