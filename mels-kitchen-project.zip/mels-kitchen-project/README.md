# Mels Kitchen

Luxury catering and gourmet food website.

## Run locally

npm install
npm run dev
